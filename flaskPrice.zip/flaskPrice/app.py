import numpy as np
from flask import Flask, render_template, request
import pickle
import os
import pandas as pd

app = Flask(_name_)
pipeline = pickle.load(open('model.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('priceApp.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Access the form data sent by the HTML file
        region_number = request.form['Region_number']
        type_num = request.form['type_num']
        room_number = request.form['room_number']
        area = request.form['Area']
        price = request.form['price']
        floor = request.form['floor']
        has_elevator = request.form['hasElevator ']
        has_parking = request.form['hasParking ']
        has_bars = request.form['hasBars ']
        has_storage = request.form['hasStorage ']
        condition = request.form['condition ']
        has_air_condition = request.form['hasAirCondition ']
        has_balcony = request.form['hasBalcony ']
        has_mamad = request.form['hasMamad ']
        handicap_friendly = request.form['handicapFriendly ']
        furniture = request.form['furniture ']

        # Create a DataFrame from the form data
        data = pd.DataFrame({
            'Region_number': [region_number],
            'type_num': [type_num],
            'room_number': [room_number],
            'Area': [area],
            'price': [price],
            'floor': [floor],
            'hasElevator': [has_elevator],
            'hasParking': [has_parking],
            'hasBars': [has_bars],
            'hasStorage': [has_storage],
            'condition': [condition],
            'hasAirCondition': [has_air_condition],
            'hasBalcony': [has_balcony],
            'hasMamad': [has_mamad],
            'handicapFriendly': [handicap_friendly],
            'furniture': [furniture]
        })

        # Perform your desired operations with the DataFrame (e.g., prediction)
        prediction = pipeline.predict(data)

        # Render the template with the prediction result
        return render_template('priceApp.html', prediction_text=f'Prediction: {prediction}')
    except Exception as e:
        # Log the exception for debugging purposes
        print(f"An error occurred during prediction: {str(e)}")
        # Return an error message to the user
        return render_template('priceApp.html', prediction_text='Error: An error occurred during prediction. Please try again.')


if _name_ == '_main_':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
